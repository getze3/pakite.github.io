<?php
/**
 * User Dashboard Contribute administration panel.
 *
 * @package WordPress
 * @subpackage Administration
 * @since 6.6.0
 */

/** Load WordPress Administration Bootstrap */
require_once __DIR__ . '/admin.php';

require ABSPATH . 'wp-admin/contribute.php';
